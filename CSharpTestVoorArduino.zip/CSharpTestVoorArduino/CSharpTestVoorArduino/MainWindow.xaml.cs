﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using USB_DAQBoard;

namespace CSharpTestVoorArduino
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private enum ArduinoStatus
        {
            Connected,
            Connecting,
            Disconnected
        }



        private SerialPort _arduinoPort;
        private ArduinoStatus _status;

        public MainWindow()
        {
            InitializeComponent();
            cboInladen();
            cboPoorten.SelectedIndex = 0;
            _status = ArduinoStatus.Disconnected;
        }

        private void cboInladen()
        {
            foreach (string s in SerialPort.GetPortNames())
            {
                cboPoorten.Items.Add(s);
            }
        }

        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            _status = ArduinoStatus.Connecting;
            
            _arduinoPort = new SerialPort(cboPoorten.SelectedItem.ToString());
            
            try
            {
                _arduinoPort.Open();
                _status = ArduinoStatus.Connected;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cboPoorten_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnCSVInlezen_Click(object sender, RoutedEventArgs e)
        {
            InlezenCSV(file);
        }

        string file = AppDomain.CurrentDomain.BaseDirectory + "spilog.csv";

        private void InlezenCSV(string file)
        {
            using(StreamReader sr = new StreamReader(file))
            {
                string sLijn = sr.ReadLine();

                for (int i = 0; i < 50; i++)
                {
                    //if (sLijn != null)
                    //{
                        sLijn = sr.ReadLine();
                        txtResultaat.Text += sLijn;
                        _arduinoPort.Write(sLijn);
                        
                    //}
                }
                

            }
        }

        private void btnLees_Click(object sender, RoutedEventArgs e)
        {
            LeesArduino();
        }

        private void LeesArduino()
        {
            try
            {
                //string message = _arduinoPort.ReadExisting();
                string message = _arduinoPort.ReadLine();
                Console.WriteLine(message);
            }
            catch (TimeoutException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            GeefTESTWeer();
        }

        private void GeefTESTWeer()
        {

            _arduinoPort.Write(new byte[] { Convert.ToByte("13") }, 0, 1);
        }

    }
}
